import styled from 'styled-components';

const ScrollXWrap = styled.div`
  overflow-x: auto;
`;

export default ScrollXWrap;
